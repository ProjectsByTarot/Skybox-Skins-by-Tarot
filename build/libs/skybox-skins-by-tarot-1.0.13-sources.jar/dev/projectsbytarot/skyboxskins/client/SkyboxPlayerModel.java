package dev.projectsbytarot.skyboxskins.client;

import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.model.ModelPlayer;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

public class SkyboxPlayerModel extends ModelPlayer {
    public SkyboxPlayerModel(boolean useSmallArms) {
        super(0.0F, useSmallArms);
    }

    @Override
    public void func_78088_a(
            Entity entity,
            float limbSwing,
            float limbSwingAmount,
            float ageInTicks,
            float netHeadYaw,
            float headPitch,
            float scale
    ) {
        if (!(entity instanceof AbstractClientPlayer)) {
            super.func_78088_a(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale);
            return;
        }

        AbstractClientPlayer player = (AbstractClientPlayer) entity;
        if (player.func_82150_aj()
                || !SkyboxClientHandler.isOnlinePlayer(player)
                || !SkyboxClientHandler.isSkyboxEnabled(player.func_70005_c_())) {
            super.func_78088_a(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale);
            return;
        }

        float partialTicks = ageInTicks - player.field_70173_aa;
        SkyboxShader.RenderState shaderState = SkyboxShader.begin(partialTicks, player.func_70005_c_());
        if (shaderState == null) {
            super.func_78088_a(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale);
            return;
        }

        ModelRenderer[] outerLayer = {
                field_178720_f,
                field_178730_v,
                field_178734_a,
                field_178732_b,
                field_178733_c,
                field_178731_d
        };
        boolean[] wasVisible = new boolean[outerLayer.length];
        for (int i = 0; i < outerLayer.length; i++) {
            wasVisible[i] = outerLayer[i].field_78806_j;
            outerLayer[i].field_78806_j = false;
        }

        try {
            super.func_78088_a(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale);
        } finally {
            for (int i = 0; i < outerLayer.length; i++) {
                outerLayer[i].field_78806_j = wasVisible[i];
            }
            shaderState.restore();
        }
    }
}
