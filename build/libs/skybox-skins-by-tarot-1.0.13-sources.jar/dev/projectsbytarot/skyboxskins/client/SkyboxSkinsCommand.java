package dev.projectsbytarot.skyboxskins.client;

import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.command.WrongUsageException;
import net.minecraft.util.ChatComponentText;

import java.util.Collections;
import java.util.List;

public class SkyboxSkinsCommand extends CommandBase {
    @Override
    public String func_71517_b() {
        return "skyboxskins";
    }

    @Override
    public String func_71518_a(ICommandSender sender) {
        return "/skyboxskins [settings|reload]";
    }

    @Override
    public List<String> func_71514_a() {
        return Collections.singletonList("skyboxsettings");
    }

    @Override
    public void func_71515_b(ICommandSender sender, String[] arguments) throws CommandException {
        if (arguments.length == 0
                || (arguments.length == 1 && "settings".equalsIgnoreCase(arguments[0]))) {
            openSettings();
            return;
        }
        if (arguments.length != 1) {
            throw new WrongUsageException(func_71518_a(sender));
        }

        if (!"reload".equalsIgnoreCase(arguments[0])) {
            throw new WrongUsageException(func_71518_a(sender));
        }

        boolean customSkyboxLoaded = SkyboxClientHandler.reloadSkyboxTextures();
        boolean customMaskLoaded = SkyboxClientHandler.isCustomMaskLoaded();
        String panoramaStatus = customSkyboxLoaded
                ? "Selected skybox \"" + SkyboxOneConfig.getSkyboxName(
                        SkyboxOneConfig.getActiveSkyboxId()) + "\" loaded."
                : SkyboxOneConfig.getActiveSkyboxId().isEmpty()
                        ? "Using the built-in skybox."
                        : "The selected skybox could not be loaded; using the built-in skybox.";
        String maskStatus = customMaskLoaded
                ? " Custom mask loaded."
                : " Using the full-skin mask; optional mask path: "
                        + SkyboxClientHandler.getCustomMaskFile().getAbsolutePath() + ".";
        sender.func_145747_a(new ChatComponentText(panoramaStatus + maskStatus));
    }

    private void openSettings() {
        SkyboxClientHandler.requestSettingsScreen();
    }

    @Override
    public int func_82362_a() {
        return 0;
    }
}
