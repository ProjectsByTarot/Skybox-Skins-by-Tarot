package dev.projectsbytarot.skyboxskins.client;

import dev.projectsbytarot.skyboxskins.SkyboxSkins;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;
import org.lwjgl.input.Keyboard;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public class SkyboxFilePickerScreen extends GuiScreen {
    private static final int FILE_LIST_TOP = 140;
    private static final String[] IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".bmp", ".gif"};

    private final GuiScreen parentScreen;
    private final boolean mask;
    private final List<File> entries = new ArrayList<File>();

    private GuiTextField pathField;
    private GuiTextField searchField;
    private File currentDirectory;
    private int page;
    private int pageSize;
    private String status = "";

    public SkyboxFilePickerScreen(GuiScreen parentScreen, boolean mask, File initialDirectory) {
        this.parentScreen = parentScreen;
        this.mask = mask;
        this.currentDirectory = initialDirectory;
    }

    @Override
    public void func_73866_w_() {
        pageSize = Math.max(1, Math.min(13, (field_146295_m - 234) / 22));
        pathField = new GuiTextField(0, field_146289_q, 12, 40, field_146294_l - 106, 20);
        pathField.func_146203_f(512);
        pathField.func_146180_a(currentDirectory == null ? "" : currentDirectory.getAbsolutePath());
        searchField = new GuiTextField(1, field_146289_q, 12, 92, field_146294_l - 24, 20);
        searchField.func_146203_f(64);
        refreshEntries();
        rebuildButtons();
    }

    @Override
    protected void func_146284_a(GuiButton button) {
        if (!button.field_146124_l) {
            return;
        }

        if (button.field_146127_k == 1) {
            navigateUp();
        } else if (button.field_146127_k == 2) {
            navigateTo(new File(System.getProperty("user.home", ".")));
        } else if (button.field_146127_k == 3) {
            navigateToPictures();
        } else if (button.field_146127_k == 4) {
            refreshEntries();
            rebuildButtons();
        } else if (button.field_146127_k == 5) {
            field_146297_k.func_147108_a(parentScreen);
        } else if (button.field_146127_k == 6) {
            page--;
            rebuildButtons();
        } else if (button.field_146127_k == 7) {
            navigateToPath();
        } else if (button.field_146127_k == 8) {
            page++;
            rebuildButtons();
        }
    }

    @Override
    protected void func_73869_a(char typedChar, int keyCode) throws IOException {
        if (pathField.func_146206_l()) {
            if (keyCode == Keyboard.KEY_RETURN || keyCode == Keyboard.KEY_NUMPADENTER) {
                navigateToPath();
                return;
            }
            if (pathField.func_146201_a(typedChar, keyCode)) {
                return;
            }
        }
        if (searchField.func_146201_a(typedChar, keyCode)) {
            page = 0;
            refreshEntries();
            rebuildButtons();
            return;
        }
        super.func_73869_a(typedChar, keyCode);
    }

    @Override
    protected void func_73864_a(int mouseX, int mouseY, int mouseButton) throws IOException {
        pathField.func_146192_a(mouseX, mouseY, mouseButton);
        searchField.func_146192_a(mouseX, mouseY, mouseButton);
        if (mouseButton == 0 && mouseX >= 12 && mouseX < field_146294_l - 12
                && mouseY >= FILE_LIST_TOP) {
            int row = (mouseY - FILE_LIST_TOP) / 22;
            int rowTop = FILE_LIST_TOP + row * 22;
            int entryIndex = page * pageSize + row;
            if (row < pageSize && mouseY < rowTop + 20 && entryIndex < entries.size()) {
                selectEntry(entries.get(entryIndex));
                return;
            }
        }
        super.func_73864_a(mouseX, mouseY, mouseButton);
    }

    @Override
    public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
        func_146276_q_();
        func_73732_a(field_146289_q, mask ? "Choose a 64x64 skin mask" : "Choose a skybox image",
                field_146294_l / 2, 18, 0xFFFFFF);
        pathField.func_146194_f();
        if (pathField.func_146179_b().isEmpty()) {
            func_73731_b(field_146289_q, "Type or paste a folder or image path", 17, 46, 0x777777);
        }
        searchField.func_146194_f();
        if (searchField.func_146179_b().isEmpty()) {
            func_73731_b(field_146289_q, "Search this folder", 17, 86, 0x777777);
        }
        int pageCount = Math.max(1, (entries.size() + pageSize - 1) / pageSize);
        String pageText = entries.isEmpty()
                ? "No matching images or folders."
                : "Page " + (page + 1) + " of " + pageCount + " (" + entries.size()
                        + " items). Use Next for more folders.";
        func_73731_b(field_146289_q, field_146289_q.func_78269_a(pageText, field_146294_l - 190),
                12, 118, 0xAAAAAA);
        drawFileRows(mouseX, mouseY);
        String statusText = status.isEmpty()
                ? "Click a folder to open it or an image to import. PNG, JPG, BMP and GIF are supported."
                : status;
        func_73732_a(field_146289_q, field_146289_q.func_78269_a(statusText, field_146294_l - 24),
                field_146294_l / 2, field_146295_m - 66, 0xFFFFFF);
        super.func_73863_a(mouseX, mouseY, partialTicks);
    }

    @Override
    public boolean func_73868_f() {
        return false;
    }

    private void refreshEntries() {
        entries.clear();
        status = "";

        try {
            if (currentDirectory == null) {
                File[] roots = File.listRoots();
                if (roots != null) {
                    for (File root : roots) {
                        if (matchesSearch(root.getPath())) {
                            entries.add(root);
                        }
                    }
                }
            } else {
                File[] children = currentDirectory.listFiles();
                if (children == null) {
                    status = "Cannot read this folder.";
                    SkyboxSkins.LOGGER.warn("Cannot list image-picker folder {}.", currentDirectory);
                } else {
                    for (File child : children) {
                        if ((child.isDirectory() && matchesSearch(child.getName()))
                                || (child.isFile() && isImageFile(child)
                                && matchesSearch(child.getName()))) {
                            entries.add(child);
                        }
                    }
                    Collections.sort(entries, new Comparator<File>() {
                        @Override
                        public int compare(File first, File second) {
                            if (first.isDirectory() != second.isDirectory()) {
                                return first.isDirectory() ? -1 : 1;
                            }
                            return first.getName().compareToIgnoreCase(second.getName());
                        }
                    });
                }
            }
        } catch (SecurityException exception) {
            status = "Access to this folder was denied.";
            SkyboxSkins.LOGGER.warn("Access denied while listing image-picker folder {}.", currentDirectory,
                    exception);
        }

        page = Math.max(0, Math.min(page, Math.max(0, (entries.size() - 1) / pageSize)));
    }

    private void rebuildButtons() {
        field_146292_n.clear();
        int parentButtonY = 66;
        int leftButtonWidth = Math.min(80, Math.max(30, (field_146294_l - 118) / 4));
        GuiButton upButton = new GuiButton(1, 12, parentButtonY, leftButtonWidth, 20,
                currentDirectory != null && currentDirectory.getParentFile() == null ? "Drives" : "Up");
        upButton.field_146124_l = currentDirectory != null;
        field_146292_n.add(upButton);
        field_146292_n.add(new GuiButton(2, 18 + leftButtonWidth, parentButtonY, leftButtonWidth, 20, "Home"));
        field_146292_n.add(new GuiButton(3, 24 + leftButtonWidth * 2, parentButtonY, leftButtonWidth, 20, "Pics"));
        field_146292_n.add(new GuiButton(4, 30 + leftButtonWidth * 3, parentButtonY, leftButtonWidth, 20, "Scan"));
        field_146292_n.add(new GuiButton(5, field_146294_l - 82, parentButtonY, 70, 20, "Cancel"));
        GuiButton goButton = new GuiButton(7, field_146294_l - 82, 40, 70, 20, "Go");
        field_146292_n.add(goButton);

        int firstEntry = page * pageSize;
        int lastEntry = Math.min(entries.size(), firstEntry + pageSize);

        int navigationY = 112;
        GuiButton previous = new GuiButton(6, field_146294_l - 172, navigationY, 70, 20, "Previous");
        GuiButton next = new GuiButton(8, field_146294_l - 94, navigationY, 82, 20, "Next");
        previous.field_146124_l = page > 0;
        next.field_146124_l = lastEntry < entries.size();
        field_146292_n.add(previous);
        field_146292_n.add(next);
    }

    private void drawFileRows(int mouseX, int mouseY) {
        int firstEntry = page * pageSize;
        int lastEntry = Math.min(entries.size(), firstEntry + pageSize);
        for (int i = firstEntry; i < lastEntry; i++) {
            int row = i - firstEntry;
            int top = FILE_LIST_TOP + row * 22;
            boolean hovered = mouseX >= 12 && mouseX < field_146294_l - 12
                    && mouseY >= top && mouseY < top + 20;
            int background = hovered ? 0xCC555555 : 0xAA222222;
            Gui.func_73734_a(12, top, field_146294_l - 12, top + 20, background);
            Gui.func_73734_a(12, top, field_146294_l - 12, top + 1, 0xFF666666);

            File entry = entries.get(i);
            String label = entry.isDirectory() ? "[Folder] " + getDisplayName(entry) : entry.getName();
            int color = entry.isDirectory() ? 0xFFFFFF : 0xDDDDDD;
            func_73731_b(field_146289_q, field_146289_q.func_78269_a(label, field_146294_l - 40),
                    20, top + 6, color);
        }
    }

    private void navigateUp() {
        if (currentDirectory == null) {
            return;
        }

        currentDirectory = currentDirectory.getParentFile();
        page = 0;
        searchField.func_146180_a("");
        updatePathField();
        refreshEntries();
        rebuildButtons();
    }

    private void navigateToPath() {
        String path = pathField.func_146179_b().trim();
        if (path.length() >= 2 && path.startsWith("\"") && path.endsWith("\"")) {
            path = path.substring(1, path.length() - 1);
        }
        if (path.isEmpty()) {
            currentDirectory = null;
            page = 0;
            searchField.func_146180_a("");
            refreshEntries();
            rebuildButtons();
            return;
        }

        File target = new File(path);
        if (!target.isAbsolute()) {
            File base = currentDirectory == null
                    ? new File(System.getProperty("user.home", "."))
                    : currentDirectory;
            target = new File(base, path);
        }

        try {
            if (target.isFile() && isImageFile(target)) {
                selectEntry(target);
                return;
            }
            navigateTo(target);
        } catch (SecurityException exception) {
            status = "Access to the requested path was denied.";
            SkyboxSkins.LOGGER.warn("Access denied for image-picker path {}.", target, exception);
        }
    }

    private void navigateTo(File directory) {
        try {
            if (!directory.isDirectory()) {
                status = "Folder not found: " + directory.getAbsolutePath();
                return;
            }

            currentDirectory = directory.getCanonicalFile();
            page = 0;
            searchField.func_146180_a("");
            updatePathField();
            refreshEntries();
            rebuildButtons();
        } catch (IOException | SecurityException exception) {
            status = "Could not open folder: " + exception.getMessage();
            SkyboxSkins.LOGGER.warn("Could not open image-picker folder {}.", directory, exception);
        }
    }

    private void navigateToPictures() {
        File home = new File(System.getProperty("user.home", "."));
        File pictures = new File(home, "Pictures");
        if (!pictures.isDirectory()) {
            pictures = new File(new File(home, "OneDrive"), "Pictures");
        }
        navigateTo(pictures);
    }

    private void updatePathField() {
        pathField.func_146180_a(currentDirectory == null ? "" : currentDirectory.getAbsolutePath());
    }

    private void selectEntry(File entry) {
        try {
            if (entry.isDirectory()) {
                currentDirectory = entry;
                page = 0;
                searchField.func_146180_a("");
                refreshEntries();
                rebuildButtons();
                return;
            }

            SkyboxTextures.ImportResult result = SkyboxTextures.importImage(entry, mask);
            status = result.message;
            if (result.success) {
                SkyboxOneConfig.reportAction(result.message);
                field_146297_k.func_147108_a(parentScreen);
            }
        } catch (SecurityException exception) {
            status = "Access to the selected file was denied.";
            SkyboxSkins.LOGGER.warn("Access denied for image-picker entry {}.", entry, exception);
        }
    }

    private boolean matchesSearch(String name) {
        String query = searchField.func_146179_b().trim().toLowerCase(Locale.ROOT);
        return query.isEmpty() || name.toLowerCase(Locale.ROOT).contains(query);
    }

    private static boolean isImageFile(File file) {
        String name = file.getName().toLowerCase(Locale.ROOT);
        for (String extension : IMAGE_EXTENSIONS) {
            if (name.endsWith(extension)) {
                return true;
            }
        }
        return false;
    }

    private static String getDisplayName(File file) {
        String name = file.getName();
        return name.isEmpty() ? file.getAbsolutePath() : name;
    }
}
